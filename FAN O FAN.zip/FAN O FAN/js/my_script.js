<!--Nut Back to top-->
$(document).ready(function() {
   setTimeout(function(){
	   $("#pre-loader").fadeOut(1000);
   },500);

   $('body').append('<p id="gb-top-page">â†‘</p>');
   $(window).scroll(function() {
		if($(window).scrollTop() != 0){
			$('#gb-top-page').fadeIn();
		}else {
			$('#gb-top-page').fadeOut();
		}
   });

   $('#gb-top-page').click(function() {
		$('html, body').animate({scrollTop:0},500);
   });

   smoothScrolling();
   function smoothScrolling() {
	  try {$.browserSelector();
		if ($("html").hasClass("chrome")) {
		  $.smoothScroll();
		}
	  }catch (err) {}
	}

  $(document).on('click','#baophu, .close-popup',function(){
		$('#baophu, .login-popup').fadeOut(300, function(){
			$('#baophu').remove();
			$('.login-popup').remove();
		});
	});
});
<!--Nut Back to top-->

<!--Kiá»ƒm tra liĂªn há»‡-->
function isEmpty(str,text){
		if(str != "") return false;
		if(typeof(text) != 'undefined')	alert(text);
		return true;
}
function isPhone(str,text){
	if((str.length==11 && (str.substr(0,2)==01)) || (str.length==10 && (str.substr(0,2)==09)))
		return false;
	if(typeof(text)!='undefined') alert(text);
	return true;
}
function isEmail(str, text){
	emailRegExp = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.([a-z]){2,4})$/;
	if(emailRegExp.test(str)){
		return false;
	}
	if(typeof(text)!='undefined') alert(text);
	return true;
}
function isSpace(str,text){
	for(var i=0; i < str.length; i++)
	{
		if((str.charAt(i)) == " ")
		{
			if(typeof(text)!='undefined') alert(text);
			return true;

		}
	}
	return false;
}
function isCharacters(str,text){
	if(str=='') return false;
	var searchReg = /^[a-zA-Z0-9-]+$/;
	if(searchReg.test(str)) {
		return false;
	}
	if(typeof(text)!='undefined') alert(text);
	return true;
}
function isRepassword(str,str2,text){
	if(str2=='') return false;
	if(str==str2) return false;
	if(typeof(text)!='undefined') alert(text);
	return true;
}
function isCharacterlimit(str,text,intmin,intmax){
	if(str=='') return false;
	intmin = parseInt(intmin);
	intmax = parseInt(intmax);

	if(str.length>=intmin && str.length<=intmax)
	{
		return false;
	}
	if(typeof(text)!='undefined') alert(text);
	return true;
}
function add_popup(str){
	$('body').append('<div class="login-popup"><div class="close-popup">x</div><div class="popup_thongbao"><p class="tieude_tb">ThĂ´ng bĂ¡o</p><p class="popup_kq">'+str+'</p></div></div>');
	$('.thongbao').html('');
	$('.login-popup').fadeIn(300);
	$('.login-popup').width($('.popup_thongbao').width()+'px')
	var chieurong = $('.login-popup').width() /2;
	$('.login-popup').css({width:$('.popup_thongbao').width()+'px','margin-left':-chieurong,top:-100+'px'});
	$('.login-popup').animate({top:100+'px'},500);
	$('body').append('<div id="baophu"></div>');
	$('#baophu').fadeIn(300);
	return false;
}

function add_popup2(str){
	$('body').append('<div id="myModal" class="modal"><div class="modal-content"><span class="close">&times;</span><p>'+str+'</p></div></div>');
	return false;
}

<!--Kiá»ƒm tra liĂªn há»‡-->
